package com.iwinner.scala.methods

object MethodObjectExample {

  def ops1(): Unit = {

    println("From OPS1");
  }

  def ops2(): Unit = {
    println("From OPS2");

  }

  def ops3(): Unit = {
    println("From OPS3");

  }

  def ops4(): Unit = {
    println("From OPS4");

  }
  def main(args: Array[String]): Unit = {
    println("MethodObjectExample main method is calling from JVM");

    var countInt1 = 10;
    // (OR)
    var countInt2: Int = 20; // Recommanded Apporach because easily identified by the dataType

    println("Count_1 of Int value" + countInt1);

    println("Count_2 of Int value" + countInt2);

    var ch = 'M';
    //  (or)
    var ch1: Char = 'F';
 
    ops1();
    ops2();
    ops3();
    ops4();

  }

  //def additionOperation()

  // public static void main(String arg[]){  }
}