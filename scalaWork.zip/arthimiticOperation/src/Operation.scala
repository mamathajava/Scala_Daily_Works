

class Operation {

  // Global Variable  ( it will be global for Class Level
  def addition(firstValue: Int, secondValue: Int): Int = {

    // Local Variable it will use with in the method (Note: Not in the class Level
    var res = firstValue + secondValue;
    return res;
  }

  def sub(oneValue: Int, twoValue: Int): Int = {

    var res = oneValue - twoValue;

    return res;
  }

  def multi(oneVariable: Int, twovaraible: Int): Int = {

    var res = oneVariable * twovaraible;
    return res;
  }

  def div(oneVariable: Int, twoVar: Int): Int = {

    var res = oneVariable / twoVar;

    return res;
  }
}