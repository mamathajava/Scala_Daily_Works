

object OperationMain {

  def main(args: Array[String]): Unit = {

    var myClass = new Operation();
    var firstValue = 30;
    var secondValue = 10;

    var addition = myClass.addition(firstValue, secondValue);

    var subtraction = myClass.sub(firstValue, secondValue);

    var mul = myClass.multi(firstValue, secondValue);

    var division = myClass.div(firstValue, secondValue);

    println("Addtion of 2 numbers " + addition);
    println("subtraction of 2 numbers " + subtraction);
    println("mul of 2 numbers " + mul);
    println("division of 2 numbers " + division);

  }
  def mainBackUP(args: Array[String]): Unit = {

    var myClass = new Operation();

    var res: Int = myClass.addition(10, 20);
    // OR
    // var res1 = myClass.addition(10, 20);

    println("Addition of 2 numbes " + res);

    var subRes: Int = myClass.sub(30, 20);

    println("Sub Res===>" + subRes);

    var mul = myClass.multi(20, 6);

    println("Multiplication of 2 numbers " + mul);

    var division = myClass.div(20, 2);

    println("Division of 2 numbers" + division);

  }
}