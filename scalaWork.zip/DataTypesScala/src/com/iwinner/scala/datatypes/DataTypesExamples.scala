package com.iwinner.scala.datatypes

object MethodObjectExample {
  
  /*  Byte
  Short
  Char
  Int
  Float
  Long
  Double
  Boolean
  String*/
  def main(args: Array[String]): Unit = {
    println("MethodObjectExample main method is calling from JVM");

    var countInt1 = 10;
    // (OR)
    var countInt2: Int = 20; // Recommanded Apporach because easily identified by the dataType

    println("Count_1 of Int value" + countInt1);

    println("Count_2 of Int value" + countInt2);

    var ch='M';
     //  (or)
    var ch1:Char='F';
  }

  //def additionOperation()

  // public static void main(String arg[]){  }
}