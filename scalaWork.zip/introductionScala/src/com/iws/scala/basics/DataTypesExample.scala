package com.iws.scala.basics

object DataTypesExample {

  def main(args: Array[String]): Unit = {

  }

}