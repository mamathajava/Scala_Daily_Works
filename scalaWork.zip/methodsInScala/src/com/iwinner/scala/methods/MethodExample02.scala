package com.iwinner.scala.methods

class MethodExample02 {
  
}