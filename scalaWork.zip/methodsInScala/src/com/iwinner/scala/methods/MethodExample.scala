



package com.iwinner.scala.methods

class MethodExample {

  def operation(): Unit = {

    println("Welcome to Scala");
    
    
  }
}