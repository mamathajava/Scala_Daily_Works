package com.iwinner.objects.scala

class ScalaClassOne {

  def scalaClassOne(): Unit = {

    println("From ScalaClassOne class from operationOne Jar ");
  }
}