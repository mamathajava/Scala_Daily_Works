package com.iwinner.objects.scala

object ScalaObjectOne {

  def sayHelloScalaObject(): Unit = {

    println("Inside the sayHelloScalaObject() From operationOne jar file scalaObject");

  }
}