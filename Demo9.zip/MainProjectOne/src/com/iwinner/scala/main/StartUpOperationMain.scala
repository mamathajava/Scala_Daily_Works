package com.iwinner.scala.main

import com.iwinner.objects.scala.ScalaObjectOne
import com.iwinner.objects.scala.ScalaClassOne

object StartUpOperationMain {
  def main(args: Array[String]): Unit = {
    
    // accessing the Scala Object
    ScalaObjectOne.sayHelloScalaObject();
    
    
    // accessing the Scala Class 
    var scalaClass=new ScalaClassOne;
    
    // Here accesing the method name
    scalaClass.scalaClassOne();
    
  }
}