package com.iwinner.scala.examples

object IfStatmentsExample {

  def main(args: Array[String]): Unit = {

    var name = "anji";

    var ticketIsHaveNot = false;

  /*  if (ticketIsHaveNot) {
      println("allowed");
    } else {
      println("Not Allowed");
    }
  */  
  
  var id=20;
  
  if(id==20){
    println("Your have enter value is correct");
  }else{
    
    println("Your have enter value is INcorrect");
  }
  }
  
  
}