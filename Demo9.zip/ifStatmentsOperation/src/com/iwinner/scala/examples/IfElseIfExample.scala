package com.iwinner.scala.examples

object IfElseIfExample {
  
  
    def ifElseIfElse(): Unit = {

      var marks: Int = 32;

      if (marks >= 80) {
        println("Excellent===> Marks");
      } else if (marks <= 80 && marks >= 70) {
        println("Good ===>>Marks");
      } else if (marks <= 70 && marks >= 50) {
        println("Avg");
      } else {

        println(" Below avg");
      }

    }

  def main(args: Array[String]): Unit = {

    ifElseIfElse();
  }

  def ifElseIf(): Unit = {

    var marks: Int = 62;

    if (marks >= 80) {
      println("Excellent===> Marks");
    } else if (marks <= 80 && marks >= 70) {
      println("Good ===>>Marks");
    } else {
      println("Avg");
    }

  }
}