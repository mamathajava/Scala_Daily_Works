package com.iwinner.scala.examples

import scala.io.StdIn//

object LargestNumberFromUser {

  def main(args: Array[String]): Unit = {

    println("Please Enter a First Number");
    val firstNumber = StdIn.readInt();

    println("Please Enter second NUmber");
    val secondNumber = StdIn.readInt();

    println("Given First number is " + firstNumber);
    println("Given secondNumber number is " + secondNumber);

    if (firstNumber > secondNumber) {
      println("First number is Big");
    } else {
      println("Second number is Big");
    }
  }
}