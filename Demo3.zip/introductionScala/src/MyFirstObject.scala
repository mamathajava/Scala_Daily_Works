
object MyFirstObject {

  def main(args: Array[String]): Unit = {

    var myClass = new MyFirstClass(); // Creating the Object MyFirstClass

    var x: Int = myClass.addition(10, 20); // Calling method or Business Operation()

    println("Addition is " + x); // Printing the Output to the User .
  }
}