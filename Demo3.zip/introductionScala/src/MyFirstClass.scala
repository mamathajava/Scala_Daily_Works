

<<<<<<< HEAD



=======
>>>>>>> branch 'master' of https://github.com/anjijava16/Scala_Daily_Works.git
class MyFirstClass {
  def main(args: Array[String]): Unit = {
    println("Hello");
  }

  def addition(x: Int, y: Int): Int = {

    return x + y;
  }

  def sayHelloWordMessage(message: String): String = {

    return "Good Evening==>>" + message;
  }
}