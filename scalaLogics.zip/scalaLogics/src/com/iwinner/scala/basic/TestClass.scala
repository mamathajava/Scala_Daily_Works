package com.iwinner.scala.basic

class TestClass {
  
}