package com.iwinner.scala.basic

/**
 * My first scala application
 */
object HelloWorld {
  def main(args: Array[String]) = println("Hi!")
}