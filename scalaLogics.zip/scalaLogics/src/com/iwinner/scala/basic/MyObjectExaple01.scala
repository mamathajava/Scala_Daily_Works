package com.iwinner.scala.basic

import scala.io.StdIn

class MyClassExample02 {

  def operation1(name: String): String = {

    var response = "Welcome to " + name;

    return response;

  }
}
object MyObjectExaple01 {

  def main(args: Array[String]): Unit = {

    var ref = new MyClassExample02();

    println("Enter yours input name");
    
    var input: String = StdIn.readLine();
    
   var output: String = ref.operation1(input)

    println("Output ==>" + output);
  }
}