package com.iwinner.scala.logics

object TuplesExample {

  def main(args: Array[String]): Unit = {

    val res = (1, 4, "BGK", "");

    println(res._1);
    
    println("New INdia ".partition(_.isUpper));
    

  }
}