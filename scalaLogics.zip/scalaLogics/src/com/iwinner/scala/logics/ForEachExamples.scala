package com.iwinner.scala.logics

class ForEachExamples {

  def forEachWay1(): Unit = {

    var name = "HEllo welcome to Scala ";

    name.foreach { names => println(names) };
  }

  def forEachWay2(): Unit = {

    var name = "HEllo welcome to Scala ";

    name.foreach(println);

  }

}