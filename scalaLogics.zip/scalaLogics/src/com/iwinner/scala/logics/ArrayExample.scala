package com.iwinner.scala.logics

import scala.io.StdIn

object ArrayExample {

  def main(args: Array[String]): Unit = {

    var ids2 = Array[Int](1, 2, 3, 4, 5);
    println("Array size is " + ids2.size);
    println("Array length is " + ids2.length);

    var ids3 = Array[String]("aa", "cmamajds", "aaa", "aaab");
    println("Array size is " + ids3.size);
    println("Array length is " + ids3.length);
    for (ref <- ids3) {
      println("Ref here " + ref);
    }

  }
  def main3(args: Array[String]): Unit = {

    arrayInsertion();

    //creting the Array Object
    var ids = new Array[Int](3); //
    println(ids);

    // inserting 
    ids(0) = 0;
    ids(1) = 1;
    ids(2) = 2;

    println("One value is ===>" + ids(0));
    println("One value is ===>" + ids(1));
    println("One value is ===>" + ids(2));
    // Size of array 
    println("Size of array is => " + ids.length);

    // display
    for (info <- ids) {
      println(info);
    }

  }

  def arrayInsertion(): Unit = {

    println("Enter arraySize ");
    var size = StdIn.readInt();

    // Array Creation on Dynamically size
    var array = new Array[Int](size);

    // Array Insertion 
    for (i <- 1 until size) {
      array(i) = i;
    }
    println("Length==>" + array.length);
    // Displaying the values
    for (ref <- array) {
      println("Arrays Values ==>" + ref);
    }

  }
  def main1(arg1: Array[String]): Unit = {

    arrayInsertion();

    // Single Value assign purpose
    var name: String = "Karihk";
    /*
     var ba=new Array[String](6);
     
     var ids2=Array[String]();
     */

    var ids = new Array[Int](4);
    ids(0) = 0;
    ids(1) = 1;
    ids(2) = 2;
    ids(3) = 3;
    println(ids.length);

    var ids2 = Array[Int](1, 2, 3, 4, 5);

    println("IDS2 lenghth===>" + ids2.length);

    /*
    for(x<- ids2){
      println(x);
    }
    */
    /*  var numbs = new Array[Int](10);

    var names = new Array[String](10);
    names(1) = "Raju";
    names(2) = "Raju";
    names(3) = "Raju";
    names(4) = "Raju";

    println(names.mkString);
    names.foreach { nam => println(nam) };*/
  }
}