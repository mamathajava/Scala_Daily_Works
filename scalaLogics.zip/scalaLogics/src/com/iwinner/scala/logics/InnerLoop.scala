package com.iwinner.scala.logics

class InnerLoop {

  def innerLoop(): Unit = {

    for (i <- 1 to 2; j <- 1 to 3) {
      println(10 * i + j);
    }
  }
}