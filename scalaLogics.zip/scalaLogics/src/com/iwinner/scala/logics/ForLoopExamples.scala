package com.iwinner.scala.logics

object ForLoopExamples {
  
  /**
   * 
   * 
   *  1 to 100 
   */
  def main(args: Array[String]): Unit = {
    
    for(i <- 1 until 10){
      println(" i value "+i);
    }
    
  }
}