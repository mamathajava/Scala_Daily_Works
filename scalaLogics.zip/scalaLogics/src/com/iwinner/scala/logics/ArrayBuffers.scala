package com.iwinner.scala.logics

import scala.collection.mutable.ArrayBuffer

object ArrayBuffers {

  def main(args: Array[String]): Unit = {

    val num = new ArrayBuffer[Int]();
    num += 1;
    num += 2;
   num+=(3,4,5,6);
    println(num);
    
    println(num.mkString("*"))
    var min= Array(1,2,3,4).min;
    println(min);
    
    
    var max= Array(1,2,3,4).max;
    
    
    println(max);
  }
}