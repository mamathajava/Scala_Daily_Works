package com.iwinner.scala.logics

class ForLoopsExamples {

 
  def forLoopWay1(): Unit = {

    for (i <- 1 to 10) {
      println(i);
    }
  }
  
  
}