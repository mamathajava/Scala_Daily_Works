package com.iwinner.scala.logics

import scala.io.StdIn.{ readLine, readInt, readDouble, readChar }

object ReaderConsoleUtils {
  def main(args: Array[String]): Unit = {

    println("Enter yours name");
    val name = readLine();

    println("Enter your Id");
    val id = readInt();

    println("Enter yours salary");
    val salary = readDouble();

    println("Enter yours Geneder");

    val ch = readChar();

    println(name + " " + id + " " + salary + "  " + ch);
    
    

  }
}