package com.iwinner.scala.logics

object StringArray {
  def main(args: Array[String]): Unit = {

    var str = new Array[String](3);
    str(0) = "abc";
    str(1) = "def";
    str(2) = "ijk";

    for (ref <- str) {
      println("Ref");
      println(ref);
    }
  }
}