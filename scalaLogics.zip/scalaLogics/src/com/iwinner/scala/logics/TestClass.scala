package com.iwinner.scala.logics

class TestClass {
  
  
  
}