package com.iwinner.scala.logics

object AccessBlockVariables {

  def accessBlockVariableExample(): Unit = {
    val x = { val a = 100; val b = 200; b - a };
    println(x);
  }

  def yieldExample(): Unit = {
    val x = for (i <- 1 to 10) yield i;
    println(x);

  }
  def customMethod(name: String, name2: String = "Anji", name3: String = "Shekar"): Unit = {

    println("name1 ==>>" + name);
    println("name2 ==>>" + name2);
    println("name3 ==>>" + name3);
  }
  def main(args: Array[String]): Unit = {
    // accessBlockVariableExample();
    // ifExample();
    // forEachWay1();
    //forEachWay2();
    //forLoopWay2();

    // innerLoop();

    // innerCompelxLoop();
    //yieldExample();

    customMethod("hhhh");

    customMethod("ajka", "ajdjda","jakjfad");
  }

  def lazyVariable(): Unit = {

    lazy val file = scala.io.Source.fromFile("test.abc").mkString;
  }

  def ifExample(): Unit = {

    var x = 10;
    var s = if (x > 6 && x < 12) "Postive" else 0;

    println(s);

  }

  def forEachWay1(): Unit = {

    var name = "HEllo welcome to Scala ";

    name.foreach { names => println(names) };
  }

  def forEachWay2(): Unit = {

    var name = "HEllo welcome to Scala ";

    name.foreach(println);

  }

  def forLoopWay1(): Unit = {

    for (i <- 1 to 10) {
      println(i);
    }

  }

  def forLoopWay2(): Unit = {

    for (i <- 1 to 10) println(i);

  }

  def innerLoop(): Unit = {

    for (i <- 1 to 2; j <- 1 to 3) {
      println(10 * i + j);
    }
  }

  def innerCompelxLoop(): Unit = {

    for (i <- 1 to 3; j <- 1 to 3 if i == j) println(10 * i + j);
  }

}