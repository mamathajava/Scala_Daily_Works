package com.iwinner.scala.logics

class Methods {

  def customMethod(name: String, name2: String = "Anji", name3: String = "Shekar"): Unit = {

    println("name1 ==>>" + name);
    println("name2 ==>>" + name2);
    println("name3 ==>>" + name3);
  }
}