package com.iwinner.scala.logics

class IFExamples {

  def ifExample(): Unit = {

    var x = 10;
    var s = if (x > 6 && x < 12) "Postive" else 0;

    println(s);

  }
}