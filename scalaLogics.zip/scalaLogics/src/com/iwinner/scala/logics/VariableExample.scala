package com.iwinner.scala.logics

class VariableExample {

  def accessBlockVariableExample(): Unit = {
    val x = { val a = 100; val b = 200; b - a };
    println(x);
  }

  def lazyVariable(): Unit = {

    lazy val file = scala.io.Source.fromFile("test.abc").mkString;
  }
}