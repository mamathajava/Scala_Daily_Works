package com.iwinner.scala.logics

object MapExamples {

  def main(args: Array[String]): Unit = {

    val map = Map("course" -> "anji");

    val res = map.get("course");
    println("Res  " + res);

    val res2 = map.getOrElse("course2", "BigData");

    println("Res=>2 " + res2);
  }
}