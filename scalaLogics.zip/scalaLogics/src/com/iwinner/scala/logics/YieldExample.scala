package com.iwinner.scala.logics

class YieldExample {

  def yieldExample(): Unit = {
    val x = for (i <- 1 to 10) yield i;

  }
}