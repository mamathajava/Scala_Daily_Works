package com {
  package edureka {
    package scala1 {
      class Manager(name: String) {
        def description = "A manager with name " + name
      }      
    }
  }
}
