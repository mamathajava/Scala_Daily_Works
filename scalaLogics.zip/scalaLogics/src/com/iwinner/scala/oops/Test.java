package com.iwinner.scala.oops;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Test {

	public static String[] readFile() {
		String[] str = null;
		try {
			
			File file = new File("D:/");
			String sCurrentLine;
			
			BufferedReader br = new BufferedReader(new FileReader(file));

			while ((sCurrentLine = br.readLine()) != null) {
				
				System.out.println(sCurrentLine);
				
				String sp[] = sCurrentLine.split(" ");
				
			}

		} catch (Exception e) {

		}
		return str;
	}

	public static void main(String[] args) {

		String names[] = { "ajdj", "shekar", "shekar" };

		for (int i = 0; i < names.length; i++) {

			for (int j = i + 1; j < names.length; j++) {

				if (names[i].equals(names[j])) {

					System.out.println(names[j]);
				}

			}
		}

	}
}
