package com.iwinner.scala.examples

object OperationOne {

  def main(args: Array[String]): Unit = {

    //    var name = "Welcome to scala";

    var name = "Welcome";

    var id = 10;

    var ch = 'C';

    println("Length" + name.length());
    var nameRef: String = "";

    var reference = name.charAt(2);

    println("Character ===>" + reference);

  }
}