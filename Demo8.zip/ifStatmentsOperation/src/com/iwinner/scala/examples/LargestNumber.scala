package com.iwinner.scala.examples

object LargestNumber {

  def main(args: Array[String]): Unit = {

    var firstNumber = 30;
    var secondNUmber = 20;

    if (firstNumber > secondNUmber) {
      println("First number is Big");
    } else {
      println("SEcond Number is BIG");
    }
  }
}